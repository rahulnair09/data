import React ,{useState}from 'react'
import logo from './assets/investment-calculator-logo.png';
import Header1 from './Components/Header1';
import Main from './Components/Main/Main';
import S1 from './Components/SubMain/S1';


function App(){
  const [dy,setDy]=useState([])

    const savedataHandler=(yearlyData1)=>
  {
    setDy(prevt=>
    {
      return[yearlyData1,...prevt]
    })
  }

  return (
    <div>
      <div>
       <Header1 text={'Investment Calculator'}/>
      </div>

     
     
<Main onSave={savedataHandler}/>
      {/* Todo: Show below table conditionally (only once result data is available) */}
      {/* Show fallback text if no data is available */}
   
      <S1 items={dy}/>
    </div>
  );
}

export default App;
