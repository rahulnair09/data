
import S2 from "./S2"
export default function S1(props)
{
    console.log( props);

  
    console.log(props)
    return(
       <div>
        {props.items.map((dy) => (
           
            <S2
              key={dy.id}
              year={dy.year}
              yearlyInterest={dy.yearlyInterest}
              savingsEndOfYear={dy.savingsEndOfYear}
              yearlyContribution={dy.yearlyContribution}
              totalInterest={dy.totalInterest}
            />
          ))}
          </div>
    )
}