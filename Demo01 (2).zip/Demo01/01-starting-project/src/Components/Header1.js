import "./Header1.css"
import logo from "../assets/investment-calculator-logo.png";
export default function Header1(props) {
  
  return (
    <div className="header">
      <img src={logo} alt="logo" />
      <h1> {props.text}</h1>
    </div>
  );
}
