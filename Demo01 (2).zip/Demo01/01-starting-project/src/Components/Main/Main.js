import Main1 from './Main1'
export default function Main(props)
{
    const savedataHandler=(yearlyData1)=>
    {
        const yearlyData={

            ...yearlyData1,
            id:Math.random().toString()
        }
        props.onSave(yearlyData)
    }
    return(
        <div>
        
        <Main1 onSavedata={savedataHandler}/>
        </div>


    )
}